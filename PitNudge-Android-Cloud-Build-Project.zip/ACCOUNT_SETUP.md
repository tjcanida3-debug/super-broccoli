# PitNudge accounts — staged implementation (Firebase)

This Android prototype has **Account UI and cloud-auth integration code**, but **Google and Apple buttons remain disabled until a distinct Firebase project is connected**. Do not claim that the current debug APK is syncing.

## Required owner setup

1. Create a dedicated Firebase project for **PitNudge** (not a personal or unrelated project's Firebase backend).
2. Add Android app ID `com.pitnudge.app` in Firebase and download its `google-services.json` to `app/google-services.json` in a trusted working copy. The file is a client configuration (not an Apple developer secret), but avoid committing development configurations indiscriminately.
3. Enable Google sign-in in Firebase Authentication. Register **the SHA-1 fingerprint of the signing key used to sign the APK**. GitHub Actions currently uses an ephemeral debug signing key! For real testing, configure a *stable* debug/release key securely before setting up OAuth.
4. Create Cloud Firestore (be mindful of region/fees) and publish `firestore.rules` before testing writes. A Firebase project by itself is not a secure storage rules configuration.
5. To enable Apple sign-in, join the Apple Developer Program, configure Sign in with Apple Service ID, private key, Team ID and return URL using Apple's developer site, then enable `apple.com` in Firebase Authentication. **Never store Apple keys in GitHub or in an app binary.** Apple's Android flow uses an external Custom Chrome Tab.
6. After Firebase config, rebuild, test Google first, then Apple. Test offline local data, account-switching, backup restore on second device, receipts larger than current cloud limit, and unauthenticated/mismatched-UID security rules.

## Data safety
- The app **does not upload anything while signed out**.
- Once signed in, an explicit **Back up this phone** action starts syncing subsequent changes.
- It prompts before replacing cloud data or replacing local phone data with a cloud backup.
- On a fresh phone with an empty local garage, it restores an available cloud garage.
- Receipt photo data URLs can exceed Firestore's document size; this early-stage implementation pauses cloud sync above 700,000 characters. For production use per-user Firebase Storage objects with separate security rules and thumbnail uploads. Do not claim all receipts sync until that is implemented.
- Cloud records are protected by signed-in Firebase UID via the provided Firestore Security Rules.
- The current cloud schema is a single JSON snapshot; production design should use per-car and per-record documents, plus recovery/versioning and conflict resolution.
- Auto GPS background detection is not yet implemented.

## Build
The existing Actions workflow can build the project without Firebase configuration. The app stays in offline guest mode and Google/Apple controls are disabled. Add a secure owner-owned configuration and stable signing before enabling accounts.
