# PitNudge Android — phone-first starter project

PitNudge is an Android app project using the existing garage, maintenance, mechanic-search, mileage, receipt, and export screens. It **isn't an APK yet**; the APK must be built with Android Gradle or the included GitHub Actions workflow.

## What works in this first Android project
- Installed launcher icon and app name.
- Local vehicle selection and service reminders.
- Mechanic searches open Google Maps in the user's normal maps/browser app.
- Receipt photo picker and expense records (saved in the app's local WebView data).
- Business/personal trip entries and reports.
- WebView GPS trip tracking **only while the app remains open** (requires Android location permission).
- CSV / JSON export via Downloads/PitNudge on Android 10+.

## Not implemented yet
- **Hands-free background trip detection when screen is locked**, even though this is the long-term goal. Android will require a foreground location service, persistent notification, permission review, background safeguards, and device testing.
- Server sync, accounts, official vehicle maintenance intervals, automatic tax calculations, Play Store release signing.

## Build the APK in GitHub Actions (no computer needed to run the build)
1. Create a **private** GitHub repository named `PitNudge-Android`.
2. Add all project files and folders from this ZIP, keeping `.github/workflows/build-android.yml` in the correct folder. A GitHub connection with code-write permissions can make this easier. The GitHub web file upload page on mobile might require desktop mode and extracted files.
3. Go to **Actions > Build PitNudge Android APK > Run workflow**. A push to `main` will also start a build.
4. Open the successful workflow run, download the artifact called **PitNudge-debug-APK**.
5. Extract that ZIP, locate `app-debug.apk`, and transfer/install that APK on your phone. Only install APKs you trust; this is a development/debug build and is not ready for publishing on Google Play.

## Important storage warning
The existing Chrome HTML prototype and the new Android app use **different local storage**. Vehicles and expenses already entered in Chrome do not appear in the installed app automatically. Use **More > Export backup** from the old version, then **More > Import backup** in the APK. Back up before uninstalling or clearing data. Do not store sensitive receipts in a public repository.

## GPS and device safety
GPS mileage is approximate and not a verified odometer. At most one vehicle should be tracked at a time. Never operate this while driving. Always check your owner's manual for maintenance intervals and double-check tax records. App permissions are granted by the user; app does not track location in background in this starter build.

## Project layout
- `app/src/main/assets/index.html`: existing mobile UI adapted for installed Android WebView.
- `app/src/main/java/com/pitnudge/app/MainActivity.java`: Android WebView, secure local asset origin, location permission, receipt picker, map links and exports.
- `app/src/main/AndroidManifest.xml`: Android permissions and launcher configuration.
- `.github/workflows/build-android.yml`: remote APK build and download artifact.


Account UI and Firebase authentication/sync are scaffolded in v0.1.3. They require a Firebase project and stable signing setup; see ACCOUNT_SETUP.md.
