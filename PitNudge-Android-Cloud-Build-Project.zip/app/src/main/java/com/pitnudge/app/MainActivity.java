package com.pitnudge.app;

import android.Manifest;
import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private static final int REQ_GPS = 3001;
    private static final int REQ_FILE = 3002;
    private static final String HOME = "https://appassets.androidplatform.net/assets/index.html";
    private WebView webView;
    private GeolocationPermissions.Callback gpsCallback;
    private String gpsOrigin;
    private ValueCallback<Uri[]> pendingFiles;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        webView.setBackgroundColor(0xff0b1018);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setGeolocationEnabled(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(true);
        webView.getSettings().setSupportMultipleWindows(false);
        // All app JavaScript is bundled locally. Outside links open in another app.
        webView.addJavascriptInterface(new AndroidBridge(), "NativePitNudge");
        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
            .build();
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return loader.shouldInterceptRequest(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                return externalNavigation(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
                return externalNavigation(Uri.parse(url));
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback cb) {
                if (!origin.startsWith("https://appassets.androidplatform.net")) {
                    cb.invoke(origin, false, false);
                    return;
                }
                if (hasGpsPermission()) {
                    cb.invoke(origin, true, false);
                } else {
                    gpsOrigin = origin;
                    gpsCallback = cb;
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_GPS);
                }
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (pendingFiles != null) pendingFiles.onReceiveValue(null);
                pendingFiles = callback;
                try {
                    Intent chooser = new Intent(Intent.ACTION_GET_CONTENT);
                    chooser.setType("image/*");
                    chooser.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(Intent.createChooser(chooser, "Choose receipt photo"), REQ_FILE);
                    return true;
                } catch (Exception e) {
                    pendingFiles = null;
                    callback.onReceiveValue(null);
                    return false;
                }
            }
        });
        webView.loadUrl(HOME);
    }

    private boolean externalNavigation(Uri url) {
        if ("appassets.androidplatform.net".equalsIgnoreCase(url.getHost())) return false;
        String scheme = url.getScheme();
        if ("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme)
                || "tel".equalsIgnoreCase(scheme) || "geo".equalsIgnoreCase(scheme)) {
            try { startActivity(new Intent(Intent.ACTION_VIEW, url)); }
            catch (Exception e) { Toast.makeText(this, "No app available for this link", Toast.LENGTH_SHORT).show(); }
        }
        return true;
    }

    private boolean hasGpsPermission() {
        return checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override public void onRequestPermissionsResult(int code, String[] permissions, int[] grants) {
        super.onRequestPermissionsResult(code, permissions, grants);
        if (code == REQ_GPS && gpsCallback != null) {
            gpsCallback.invoke(gpsOrigin, hasGpsPermission(), false);
            gpsCallback = null;
            gpsOrigin = null;
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && pendingFiles != null) {
            Uri result = resultCode == RESULT_OK && data != null ? data.getData() : null;
            pendingFiles.onReceiveValue(result == null ? null : new Uri[]{result});
            pendingFiles = null;
        }
    }

    private class AndroidBridge {
        @JavascriptInterface public void saveFile(String fileName, String contents, String mime) {
            String safeName = fileName.replaceAll("[^a-zA-Z0-9._-]", "_");
            if (safeName.isEmpty()) safeName = "pitnudge-export.txt";
            try {
                OutputStream os;
                if (Build.VERSION.SDK_INT >= 29) {
                    ContentValues vals = new ContentValues();
                    vals.put(MediaStore.Downloads.DISPLAY_NAME, safeName);
                    vals.put(MediaStore.Downloads.MIME_TYPE, mime == null ? "text/plain" : mime);
                    vals.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/PitNudge");
                    Uri dest = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, vals);
                    if (dest == null) throw new Exception("Could not create download");
                    os = getContentResolver().openOutputStream(dest);
                } else {
                    File folder = getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS);
                    if (folder == null) throw new Exception("No storage available");
                    os = new FileOutputStream(new File(folder, safeName));
                }
                if (os == null) throw new Exception("Could not open download");
                try (OutputStream stream = os) {
                    stream.write(contents.getBytes(StandardCharsets.UTF_8));
                }
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Saved export to PitNudge downloads", Toast.LENGTH_LONG).show());
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this,
                        "Could not save export: " + e.getMessage(), Toast.LENGTH_LONG).show());
            }
        }
    }

    @Override public void onBackPressed() {
        // HTML tabs are a single local page; don't silently close the app mid-session.
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) webView.destroy();
        super.onDestroy();
    }
}
